# Parque das Nações — HTML5 display ads

Aperture Global Real Estate · English + Português · 24 units

## Open this first

`ParqueDasNacoes-preview/index.html` — double-click it. Every unit plays in one page,
grouped **English › Video**, **English › Carousel**, **Português › Video**,
**Português › Carousel**. No server and no internet connection required.

Each card has play/pause, replay and a 15-second scrubber, plus a link to open that unit on
its own and to download its backup still. The carousel arrows, dots and swipe all work
inside the preview, exactly as they will in the live ad.

## What's in the set

| | |
|---|---|
| **Sizes** | 768×1024, 1024×768, 480×320, 970×250, 320×480, 300×600 |
| **Variants** | video and carousel, in each language — 24 units total |
| **Loop** | 15 seconds, looping continuously |
| **Weight** | every unit under the 700 KB cap (largest: 1024×768 video, 666 KB) |
| **Click-through** | the underlined CTA only — not the whole ad |

**Video** units play the two listing clips as a silent 15-second loop.
**Carousel** units are interactive: four listing photos with arrows, dots and swipe, which
also auto-advance in step with the copy.

## Copy

| | English | Português |
|---|---|---|
| Eyebrow | Exclusive Offer | Oferta Exclusiva |
| Headline | Parque das Nações | Parque das Nações |
| Location | Lisbon, Portugal | Lisboa, Portugal |
| Spec | 4 br \| 5 bth \| 6,500 sqm | 4 br \| 5 bth \| 6,500 sqm |
| Agents | Listed by Liza Falcão de Sá & Charles Andrews | Listado por Liza Falcão de Sá & Charles Andrews |
| CTA | Schedule a viewing | Agendar visita |

The property name is a proper noun and stays in Portuguese in both sets. All copy is baked
to vector outlines, so the units carry no webfonts and render identically everywhere.

## Notes for whoever traffics these

- **clickTag** defaults to `apertureglobal.com` and can be overridden per placement by
  appending `?clicktag=<url>` to the unit's URL. Built for StackAdapt; the same
  convention works on most DSPs.
- **Autoplay fallback.** The video units carry the photo carousel underneath them. If a
  browser refuses to autoplay — Safari in Low Power Mode, or "Never Auto-Play" — the unit
  switches to the interactive carousel instead of showing a frozen frame. Tested in both
  states.
- **Backup stills** are included for every unit (`*_backup.jpg`), for placements that need
  a static fallback.
- **Shippable zips** are not in this package to keep it small — ask for them when you're
  ready to traffic, or take them from `animatedads/dist/parque/` in the repo.

## Reviewing on a phone

Open `index.html` on the phone itself, or view a single unit full-screen with the "open
alone" link on its card. The swipe hint on the photo band only appears on touch devices,
and disappears after the first manual swipe.
